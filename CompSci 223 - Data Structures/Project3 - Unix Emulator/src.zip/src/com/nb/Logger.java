package com.nb;

import java.util.Arrays;

/**
 * Created by Nicholas on 4/18/2015.
 */
public class Logger {
    private static int LOG_LEVEL = 3;
    public static void setLogLevel(int logLevel) {
        Logger.LOG_LEVEL = logLevel;
    }
    public static void error(String message){
        if (LOG_LEVEL>=1){
            System.out.println("ERROR: " + message + " \n" + Arrays.toString(Thread.currentThread().getStackTrace()));
        }
    }
    public static void warning(String message){
        if (LOG_LEVEL>=2){
            System.out.println("WARNING: " + message + "  at   " + Thread.currentThread().getStackTrace()[1].toString());
        }
    }
    public static void info(String message){
        if (LOG_LEVEL>=3){
            System.out.println("INFO: " + message + "  at   " + Thread.currentThread().getStackTrace()[1].toString());
        }
    }
}
