package com.nb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Created by Nicholas on 4/18/2015.
 */
public class CommandParser {
    public FileSystem fs = null;
    CommandParser(FileSystem fs){
        this.fs = fs;
    }
    public String getCommand(){
        Scanner scanner = new Scanner(System.in);
        String text = scanner.nextLine();
        return text;
    }

    /**
     * Parse A command String
     * @return
     */
    public ArrayList<String> parseCommand(String cmd){
        return new ArrayList<String>(Arrays.asList(cmd.split(" ")));
    }
    /**
     * Execute A command string
     * @return
     */
    public boolean executeCommand(String cmd){
        ArrayList<String> parsedCmd = parseCommand(cmd);
        if (parsedCmd.size() == 1 && parsedCmd.get(0).equals("")){parsedCmd.remove(0);}
        if (parsedCmd.size() >0) {
            String action = parsedCmd.remove(0).toLowerCase();
            if (action.equals("mkdir")) {
                //Check to see if the optional parameter is included
                if (!parsedCmd.isEmpty()) {
                    String arg = parsedCmd.get(0);
                    boolean createParents = false;
                    if (arg.equals("-p")) {
                        createParents = true;
                        parsedCmd.remove(0);
                    }
                    if (parsedCmd.size() > 0 ){
                        for (int i = 0; i<parsedCmd.size();){
                            if (!parsedCmd.isEmpty()) {
                                //The -p option is included, create all of the parent items if they dont exists
                                System.out.print("mkdir:");
                                String dir = parsedCmd.remove(0);
                                if(fs.createFile(dir, true, createParents)){
                                    System.out.println("Directory " + dir + " Created");
                                }
                            }
                        }
                    }else{
                        //TODO: error path argument missing
                        System.out.println("Not Enough Arguments");
                    }
                }else{
                    //TODO: Print MkDir help
                    System.out.println("Not Enough Arguments");
                }
            }
            else if (action.equals("rm")) {
                //Check to see if the optional parameter is included
                if (!parsedCmd.isEmpty()) {
                    String arg = parsedCmd.get(0);
                    boolean r = false;
                    if (arg.equals("-r")) {
                        r = true;
                        parsedCmd.remove(0);
                    }
                    if (parsedCmd.size() > 0 ){
                        for (int i = 0; i<parsedCmd.size();){
                            if (!parsedCmd.isEmpty()) {
                                //The -r option is included, delete directories and everything in them
                                System.out.print("rm:");
                                String name = parsedCmd.remove(0);
                                if (fs.removeFile(name, r)){
                                    System.out.println("File " + name + " Removed");
                                }
                            }
                        }
                    }else{
                        //todo: Error path argument missing
                        System.out.println("Not Enough Arguments");
                    }
                }else{
                    //TODO: Print rm help
                    System.out.println("Not Enough Arguments");
                }
            }
            else if (action.equals("cd")) {
                //Check to see if the optional parameter is included
                if (!parsedCmd.isEmpty()) {
                    String name = parsedCmd.remove(0);
                    fs.setWorkingDir(name);
                }else{
                    //TODO: Print cd help
                    System.out.println("Not Enough Arguments");
                }
            }
            else if (action.equals("ls")) {
                //Check to see if the optional parameter is included
                boolean r = false;
                if (!parsedCmd.isEmpty()) {
                    String arg = parsedCmd.get(0);
                    if (arg.equals("-r")) {
                        r = true;
                        parsedCmd.remove(0);
                    }
                }
                if (parsedCmd.size() > 0 ){
                    for (int i = 0; i<parsedCmd.size();){
                        if (!parsedCmd.isEmpty()) {
                            String name = parsedCmd.remove(0);
                            System.out.println(fs.listFiles(name, r));
                        }
                    }
                }else{
                    System.out.println(fs.listFiles("", r));
                }
            }
            else if (action.equals("pwd")) {
                System.out.println(fs.getWorkingDirPath());
            }
            else if (action.equals("edit")) {
                if (parsedCmd.size() > 0 ){
                    String name = parsedCmd.remove(0);
                    fs.editFile(name);
                }else{
                    System.out.println("Error Not enough Arguments");
                }
            }
            else if (action.equals("cat")) {
                if (parsedCmd.size() > 0 ){
                    for (int i = 0; i<parsedCmd.size();){
                        if (!parsedCmd.isEmpty()) {
                            String path = parsedCmd.remove(0);
                            File f = fs.getFile(path, false);
                            if (f instanceof TextFile){
                                System.out.println(((TextFile) f).getContent());
                            }else if (f == null){
                                System.out.println("File at " + path + " does not exist");
                            }else{
                                System.out.println("File at " + path + " is not a TextFile, Cannot print contents");
                            }
                        }
                    }
                }else{
                    System.out.println("Error Not enough Arguments");
                }
            }
            else if (action.equals("mv")) {
                if (parsedCmd.size() >1  ){
                    boolean c = false;
                    String src;
                    String dest;
                    String arg = parsedCmd.get(0);
                    if (arg.equals("-c")) {
                        c = true;
                        parsedCmd.remove(0);
                    }
                    src = parsedCmd.remove(0);
                    //because we just check to see if parsedCmd is greater then 1, if -c is included then it
                    // would be 3 arguments, which would not have been caught there
                    if (!parsedCmd.isEmpty()) {
                        dest = parsedCmd.remove(0);
                        fs.moveFile(src,dest,c);
                    }else{
                        System.out.println("Error Not enough Arguments");
                    }
                }else{
                    System.out.println("Error Not enough Arguments");
                }
            }
            else if (action.equals("locate")) {
                if (parsedCmd.size() >0  ){
                    String name = parsedCmd.get(0);
                    fs.searchFiles(name);
                }else{
                    System.out.println("Error Not enough Arguments");
                }
            }
            else if (action.equals("search")) {
                if (parsedCmd.size() > 0 ){
                    for (int i = 0; i<parsedCmd.size();){
                        if (!parsedCmd.isEmpty()) {
                            String word = parsedCmd.remove(0);
                            fs.searchForWord(word);
                        }
                    }
                }else{
                    System.out.println("Error Not enough Arguments");
                }
            }
            else if (action.equals("updatedb")) {
                fs.index();
            }
        }
        else{
            //Todo: ERROR Not enough Arguments print help
            System.out.println("Error Not enough Arguments");
        }
        return true;

    }
    public boolean getAndExecuteCommand(){
        return executeCommand(getCommand());
    }
}
