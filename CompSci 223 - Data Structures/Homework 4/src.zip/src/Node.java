import java.io.Serializable;

public class Node<E> implements Serializable {
    // Data Fields

    /** The information stored in this node. */
    public E data;
    /** Reference to the left child. */
    public Node<E> leftChild;
    /** Reference to the right child. */
    public Node<E> rightChild;

    // Constructors
    /**
     * Construct a node with given data and no children.
     * @param data The data to store in this node
     */
    public Node(E data) {
        this.data = data;
        leftChild = null;
        rightChild = null;
    }

    // Methods
    /**
     * Returns a string representation of the node.
     * @return A string representation of the data fields
     */
    @Override
    public String toString() {
        return data.toString();
    }
}