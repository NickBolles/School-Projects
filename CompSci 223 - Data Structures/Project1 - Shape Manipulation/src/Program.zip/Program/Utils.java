/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Program;

import java.util.Scanner;

/**
 *
 * @author Nicholas
 */
public class Utils {
     public static double[] promptForPoint(boolean allowForBlank){
        double[] coords= new double[2];
        while(true){ //Loop to make sure input is valid
            String line = Utils.scanner.nextLine();
            if (allowForBlank && line.equalsIgnoreCase("")){
                break;
            }
            String[] c = line.split(" ");
            double x,y;
            try{
                if (c.length == 2){
                    coords[0] = Double.parseDouble(c[0]);
                    coords[1] = Double.parseDouble(c[1]);
                }
                else{
                    throw new NumberFormatException();
                }
                break;
            }catch(NumberFormatException e){
                System.out.println("Error! Could not parse Number from Entry. Please Try Again.");
            }
        
        }
        return coords;    
    }
    public static int promptForInt(){
        int num=0;
        while(true){ //Loop to make sure input is valid
            try{                   
                num = Utils.scanner.nextInt();
                break;
            //catch the error if the input isn't an Int
            }catch(java.util.InputMismatchException e){
            	//provide an error message to the user and DONT 
            	//modify inputValid so that they have a chance to start again
                System.out.println("Please Enter Only Numbers");
            }
        }
        Utils.clearScanner();
        return num;
    }
    public static double promptForDouble(){
        Double num=0.0;
        while(true){ //Loop to make sure input is valid
            
            try{                   
                num = Utils.scanner.nextDouble();
                break;
            //catch the error if the input isn't an Int
            }catch(java.util.InputMismatchException e){
            	//provide an error message to the user and DONT 
            	//modify inputValid so that they have a chance to start again
                System.out.println("Please Enter Only Numbers");
            }
        } 
        Utils.clearScanner();
        return num;
    }
    public static boolean promptForBoolean(){
        while(true){ //Loop to make sure input is valid
            try{                   
                String line = Utils.scanner.nextLine();
                if (line.matches("[yY]")){return true;}
                else if (line.matches("[nN]")){return false;}
                else{
                    throw new java.util.InputMismatchException();
                }
            //catch the error if the input isn't an Int
            }catch(java.util.InputMismatchException e){
            	//provide an error message to the user and DONT 
            	//modify inputValid so that they have a chance to start again
                System.out.println("Please Enter y, Y, n, or N");
            }
        }
    }
    public static void clearScanner(){
        //Utils.scanner.close();
        //Utils.scanner = new Scanner(System.in);
        Utils.scanner.nextLine();
    }
    public static Scanner scanner = new Scanner(System.in);
}
